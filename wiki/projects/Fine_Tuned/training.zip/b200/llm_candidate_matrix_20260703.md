﻿---
type: Decision Note
title: MalwareAnalysisLLM LLM Candidate Matrix
description: B200 서버에서 MalwareAnalysisLLM fine-tuning 및 serving에 사용할 LLM 후보군을 현재 실험 결과 기준으로 재정리
tags: [llm, b200, finetuning, serving, qwen, glm, deepseek]
timestamp: 2026-07-03
status: active
---

# Summary

초기 후보군은 `B200_server.md`에서 **4×B200 기준 대형 모델 serving + LoRA fine-tuning 가능성**을 함께 고려해 잡았다. 이후 실제 LLaMA-Factory fine-tuning 실험에서 다음 사실이 확인되었다.

- 30B/72B급 모델은 LLaMA-Factory + DeepSpeed + PEFT LoRA 경로 검증에 유용하다.
- 480B FP8은 serving 극한 실험 후보로는 여전히 중요하지만, 현재 LLaMA-Factory fine-tuning에서는 checkpoint loading 중 cgroup 800GiB limit에 걸린다.
- 480B fine-tuning을 계속 밀려면 LLaMA-Factory만 고집하기보다 Megatron/NeMo 같은 large-model-native framework를 후보로 올려야 한다.

따라서 이제 후보군은 **서빙 후보**, **학습 기준선 후보**, **480B급 대형 학습 후보**, **한계 테스트 후보**로 분리한다.

# Candidate Matrix

| 후보 | 역할 | 현재 평가 | 다음 액션 |
| --- | --- | --- | --- |
| `Qwen/Qwen3-Coder-480B-A35B-Instruct-FP8` | 480B급 코딩 특화 극한 모델 | serving 실험 후보로 중요. LLaMA-Factory fine-tuning은 checkpoint loading 40% 부근에서 cgroup 800GiB 도달 | LLaMA-Factory에서는 load-only nproc 실험. 학습은 Megatron/NeMo 전환 검토 |
| `Qwen/Qwen3-Coder-480B-A35B-Instruct` | non-FP8 비교 후보 | FP8보다 memory 부담이 커서 현재 4×B200/800GiB cgroup에서는 우선순위 낮음 | FP8 load 문제가 해결된 뒤 비교 |
| `Qwen/Qwen3-Coder-30B-A3B-Instruct` | Qwen3-Coder 계열 학습 기준선 | ZeRO-3 patched smoke 통과. dataset/W&B/LLaMA-Factory 경로 검증용으로 좋음 | full 또는 longer smoke로 품질/속도 기준선 확보 |
| Qwen2/Qwen2.5 72B 계열 | 중대형 dense 학습 기준선 | 72B ZeRO-3 patched smoke 통과. 30B보다 무겁지만 B200 기준 검증 가능 | 30B 다음 단계의 안정 학습 후보 |
| `GLM-4.5-FP8` | reasoning/agent serving 비교 후보 | Qwen3-Coder 480B와 응답 성향 비교용. 기존 문서상 4×B200 serving 후보 | serving benchmark 후보로 유지 |
| `GLM-4.5-Air` / Air-FP8 | 현실적인 LoRA fine-tuning 후보 | 기존 문서에서 파인튜닝 후보로 지정. 480B보다 현실적인 반복 학습 후보 | 모델 확보 후 LLaMA-Factory/Axolotl compatibility 확인 |
| `DeepSeek-R1` / `DeepSeek-V3` | 671B급 한계 테스트 | 안정 운영/학습 후보가 아니라 4×B200 상한선 확인용 | 480B serving이 정리된 뒤 극한 serving 실험 |
| `gpt-oss-120b` | 기준선/검증 모델 | vLLM/API/client benchmark 확인용. fine-tuning 메인 후보는 아님 | serving stack sanity check에 사용 |

# Current Recommendation

## Fine-tuning 우선순위

1. **Qwen3-Coder-30B-A3B**
   - 가장 먼저 계속 학습을 돌려볼 후보.
   - Qwen3-Coder 계열이라 480B와 tokenizer/template/모델 계열이 가깝다.
   - 이미 ZeRO-3 patched smoke가 통과했다.

2. **Qwen2/Qwen2.5 72B 계열**
   - B200 4장 학습 파이프라인의 중대형 기준선.
   - 30B보다 실제 memory/throughput 압박을 더 잘 보여준다.
   - 이미 1-step smoke가 통과했다.

3. **GLM-4.5-Air**
   - 기존 후보군에서 현실적 LoRA fine-tuning 모델로 잡았던 후보.
   - Qwen 계열과 다른 reasoning/agent 성향을 비교할 때 가치가 있다.
   - 아직 현재 프로젝트 pipeline에서 실제 smoke 검증은 필요하다.

4. **Qwen3-Coder-480B FP8**
   - 최종 도전 후보.
   - 현재 LLaMA-Factory 4-rank 경로에서는 checkpoint loading 중 cgroup memory limit에 닿는다.
   - 바로 full training 대상이 아니라, load-only 실험과 framework 전환 판단 대상이다.

## Serving 우선순위

1. **Qwen3-Coder-480B FP8**
   - 코딩/agentic workload 극한 serving 후보.

2. **GLM-4.5-FP8**
   - reasoning/agent 비교 후보.

3. **gpt-oss-120b**
   - serving stack 기준선.

4. **DeepSeek-R1/V3**
   - 4×B200 상한선 확인용 한계 테스트.

# Framework Implication

모델 후보는 framework 후보와 함께 봐야 한다.

| 모델 규모 | 우선 framework | 이유 |
| --- | --- | --- |
| 30B | LLaMA-Factory | 이미 smoke 통과. 빠른 반복 실험 가능 |
| 72B | LLaMA-Factory + DeepSpeed | ZeRO-3 patched smoke 통과. 중대형 기준선 |
| GLM-4.5-Air | LLaMA-Factory 또는 Axolotl | 현실적인 LoRA 반복 학습 후보 |
| 480B FP8 | LLaMA-Factory load-only 후 Megatron/NeMo 검토 | 현재 LLaMA-Factory 학습은 cgroup memory limit에 막힘 |
| 671B급 DeepSeek | vLLM serving 또는 Megatron/NeMo 계열 검토 | 안정 학습보다 한계 테스트 성격 |

# Decisions

- 480B FP8은 "바로 학습" 후보가 아니라 "대형 모델 load/framework 검증" 후보로 격하한다.
- 실제 MalwareAnalysisLLM 학습 품질 실험은 30B -> 72B -> GLM-4.5-Air 순서가 더 현실적이다.
- 480B를 포기하는 것은 아니다. 다만 LLaMA-Factory 4-rank checkpoint loading 문제가 해결되거나 Megatron/NeMo 경로가 준비된 뒤 다시 승격한다.
- serving 후보와 fine-tuning 후보를 섞어서 판단하지 않는다.

# Related Concepts

- [B200 Server Fine-Tuning](B200_server.md)
- [B200 Fine-Tuning Troubleshooting Report](b200_finetuning_troubleshooting_report_20260703.md)
- [Fine-Tuning Framework Comparison Basics](../fundamentals/finetuning_framework_comparison.md)
- [B200 480B FP8 Framework Matrix Experiments](../repos/AegisLM/docs/FRAMEWORK_MATRIX_EXPERIMENTS.md)
- [LLaMA-Factory Qwen3-Coder 480B FP8 SIGKILL Investigation](../../../errors/llamafactory-qwen3-coder-480b-fp8-oom-kill.md)
