# Fine-Tuned Project

B200 서버 기반 LLM fine-tuning, 보안 데이터셋, AegisLM/LLaMA-Factory 실험 기록을 관리한다.

## Sections

- [B200 Experiments](b200/index.md) - B200 서버, 480B/80B 모델 한계, troubleshooting, 후보군 정리
- [Data Pipeline](data/index.md) - 보안 데이터셋 추출, 전처리, SFT 포맷, split/export 흐름
- [Training Runtime](training/index.md) - LLaMA-Factory, W&B, DeepSpeed 기반 실행 가이드
- [Project Library Stack](libraries/index.md) - MalwareAnalysisLLM과 project_Nurilab에서 실제로 쓰는 라이브러리 지도
- [Fine-Tuning Fundamentals](fundamentals/index.md) - PyTorch, Transformers, LoRA, 분산 학습, telemetry 기본기
- [Repository Mirrors](repos/) - AegisLM, project_Nurilab 관련 mirror 문서와 원격 프로젝트 docs

## High-Signal Docs

- [B200 Model Limit Load-Only Probes](b200/b200_model_limit_load_only_probes.md) - B200 800GiB container profile에서 GLM, Qwen3-Coder Next, DeepSeek V4 Flash 후보의 load-only 한계 측정
- [B200 Fine-Tuning Troubleshooting Report](b200/b200_finetuning_troubleshooting_report_20260703.md) - 데이터셋, dependency, DeepSpeed, memory/cgroup 문제와 해결 내역 종합 보고서
- [MalwareAnalysisLLM LLM Candidate Matrix](b200/llm_candidate_matrix_20260703.md) - 30B/72B/480B, GLM, DeepSeek, gpt-oss 후보를 serving/fine-tuning 관점으로 정리
- [Security Datasets](data/security_datasets.md) - AegisLM 보안 fine-tuning 데이터셋 추출, 전처리, split, LLaMA-Factory export 가이드
- [LLaMA-Factory + W&B Fine-Tuning Integration](training/llamafactory_wandb_finetuning.md) - B200 서버에서 LLaMA-Factory, DeepSpeed, W&B로 Qwen3-Coder SFT를 실행하는 가이드
- [MalwareAnalysisLLM Library Stack Map](libraries/malwareanalysisllm_library_stack_map.md) - data, schema, model loading, training runtime, logging, security analysis 계층별 라이브러리 지도
