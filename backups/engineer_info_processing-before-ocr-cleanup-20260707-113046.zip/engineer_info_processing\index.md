---
type: Reference
title: "정보처리기사 실기 학습 대시보드"
description: "2026 수제비 정보처리기사 실기 기본서 내용 및 final 모의고사 문제/해설 모음집"
tags: [engineer-info-processing, index]
timestamp: 2026-06-19
status: active
---

# 정보처리기사 실기 학습 대시보드

## 기본서 1권

- [[1과목] 요구사항 확인](book1/subject01.md) - 소프트웨어 개발 방법론, 현행 시스템 분석, 요구사항 확인
- [[2과목] 화면 설계](book1/subject02.md) - UI 요구사항 확인
- [[3과목] 데이터 입출력 구현](book1/subject03.md) - 논리/물리 데이터베이스 설계, 데이터 전환
- [[4과목] 통합 구현](book1/subject04.md) - 연계 데이터 구성, 내외부 연계 모듈 구현
- [[5과목] 인터페이스 구현](book1/subject05.md) - 인터페이스 설계 및 구현
- [[6과목] 프로그래밍 언어 활용](book1/subject06.md) - 기본 문법, 언어 특성 및 라이브러리 활용
- [[7과목] 구축하려는 시스템의 환경 분석](book1/subject07.md) - 네트워크, 미디어, 보안 구축

## 기본서 2권

- [[8과목] 서버 프로그램 구현](book2/subject08.md) - 개발 환경 구축, 공통 모듈, 서버/배치 프로그램 구현
- [[9과목] 소프트웨어 개발 보안 구축](book2/subject09.md) - 소프트웨어 개발 보안 설계 및 구현
- [[10과목] 애플리케이션 테스트 관리](book2/subject10.md) - 애플리케이션 테스트케이스 설계 및 통합 테스트
- [[11과목] 응용 소프트웨어 기초 기술 활용](book2/subject11.md) - 운영체제, 네트워크 기초 기술 활용, 기본 개발환경 준비
- [[12과목] 제품 소프트웨어 패키징](book2/subject12.md) - 제품 소프트웨어 패키징, 매뉴얼 작성, 버전 관리

## Final 모의고사 문제 (20회 분량)

- [Final 모의고사 01회 (문제)](final_prob/exam01.md) - 01회 실전 테스트 문제
- [Final 모의고사 02회 (문제)](final_prob/exam02.md) - 02회 실전 테스트 문제
- [Final 모의고사 03회 (문제)](final_prob/exam03.md) - 03회 실전 테스트 문제
- [Final 모의고사 04회 (문제)](final_prob/exam04.md) - 04회 실전 테스트 문제
- [Final 모의고사 05회 (문제)](final_prob/exam05.md) - 05회 실전 테스트 문제
- [Final 모의고사 06회 (문제)](final_prob/exam06.md) - 06회 실전 테스트 문제
- [Final 모의고사 07회 (문제)](final_prob/exam07.md) - 07회 실전 테스트 문제
- [Final 모의고사 08회 (문제)](final_prob/exam08.md) - 08회 실전 테스트 문제
- [Final 모의고사 09회 (문제)](final_prob/exam09.md) - 09회 실전 테스트 문제
- [Final 모의고사 10회 (문제)](final_prob/exam10.md) - 10회 실전 테스트 문제
- [Final 모의고사 11회 (문제)](final_prob/exam11.md) - 11회 실전 테스트 문제
- [Final 모의고사 12회 (문제)](final_prob/exam12.md) - 12회 실전 테스트 문제
- [Final 모의고사 13회 (문제)](final_prob/exam13.md) - 13회 실전 테스트 문제
- [Final 모의고사 14회 (문제)](final_prob/exam14.md) - 14회 실전 테스트 문제
- [Final 모의고사 15회 (문제)](final_prob/exam15.md) - 15회 실전 테스트 문제
- [Final 모의고사 16회 (문제)](final_prob/exam16.md) - 16회 실전 테스트 문제
- [Final 모의고사 17회 (문제)](final_prob/exam17.md) - 17회 실전 테스트 문제
- [Final 모의고사 18회 (문제)](final_prob/exam18.md) - 18회 실전 테스트 문제
- [Final 모의고사 19회 (문제)](final_prob/exam19.md) - 19회 실전 테스트 문제
- [Final 모의고사 20회 (문제)](final_prob/exam20.md) - 20회 실전 테스트 문제

## Final 모의고사 해설 (20회 분량)

- [Final 모의고사 01회 (해설)](final_expl/exam01.md) - 01회 문제 정답 및 상세 해설
- [Final 모의고사 02회 (해설)](final_expl/exam02.md) - 02회 문제 정답 및 상세 해설
- [Final 모의고사 03회 (해설)](final_expl/exam03.md) - 03회 문제 정답 및 상세 해설
- [Final 모의고사 04회 (해설)](final_expl/exam04.md) - 04회 문제 정답 및 상세 해설
- [Final 모의고사 05회 (해설)](final_expl/exam05.md) - 05회 문제 정답 및 상세 해설
- [Final 모의고사 06회 (해설)](final_expl/exam06.md) - 06회 문제 정답 및 상세 해설
- [Final 모의고사 07회 (해설)](final_expl/exam07.md) - 07회 문제 정답 및 상세 해설
- [Final 모의고사 08회 (해설)](final_expl/exam08.md) - 08회 문제 정답 및 상세 해설
- [Final 모의고사 09회 (해설)](final_expl/exam09.md) - 09회 문제 정답 및 상세 해설
- [Final 모의고사 10회 (해설)](final_expl/exam10.md) - 10회 문제 정답 및 상세 해설
- [Final 모의고사 11회 (해설)](final_expl/exam11.md) - 11회 문제 정답 및 상세 해설
- [Final 모의고사 12회 (해설)](final_expl/exam12.md) - 12회 문제 정답 및 상세 해설
- [Final 모의고사 13회 (해설)](final_expl/exam13.md) - 13회 문제 정답 및 상세 해설
- [Final 모의고사 14회 (해설)](final_expl/exam14.md) - 14회 문제 정답 및 상세 해설
- [Final 모의고사 15회 (해설)](final_expl/exam15.md) - 15회 문제 정답 및 상세 해설
- [Final 모의고사 16회 (해설)](final_expl/exam16.md) - 16회 문제 정답 및 상세 해설
- [Final 모의고사 17회 (해설)](final_expl/exam17.md) - 17회 문제 정답 및 상세 해설
- [Final 모의고사 18회 (해설)](final_expl/exam18.md) - 18회 문제 정답 및 상세 해설
- [Final 모의고사 19회 (해설)](final_expl/exam19.md) - 19회 문제 정답 및 상세 해설
- [Final 모의고사 20회 (해설)](final_expl/exam20.md) - 20회 문제 정답 및 상세 해설

## Final 모의고사 원본 합본 (16회 분량)

- [Final 모의고사 01회 (문제+해설)](final_orig/exam01.md) - 01회 문제와 해설 합본 원본
- [Final 모의고사 02회 (문제+해설)](final_orig/exam02.md) - 02회 문제와 해설 합본 원본
- [Final 모의고사 03회 (문제+해설)](final_orig/exam03.md) - 03회 문제와 해설 합본 원본
- [Final 모의고사 04회 (문제+해설)](final_orig/exam04.md) - 04회 문제와 해설 합본 원본
- [Final 모의고사 05회 (문제+해설)](final_orig/exam05.md) - 05회 문제와 해설 합본 원본
- [Final 모의고사 06회 (문제+해설)](final_orig/exam06.md) - 06회 문제와 해설 합본 원본
- [Final 모의고사 07회 (문제+해설)](final_orig/exam07.md) - 07회 문제와 해설 합본 원본
- [Final 모의고사 08회 (문제+해설)](final_orig/exam08.md) - 08회 문제와 해설 합본 원본
- [Final 모의고사 09회 (문제+해설)](final_orig/exam09.md) - 09회 문제와 해설 합본 원본
- [Final 모의고사 10회 (문제+해설)](final_orig/exam10.md) - 10회 문제와 해설 합본 원본
- [Final 모의고사 11회 (문제+해설)](final_orig/exam11.md) - 11회 문제와 해설 합본 원본
- [Final 모의고사 12회 (문제+해설)](final_orig/exam12.md) - 12회 문제와 해설 합본 원본
- [Final 모의고사 13회 (문제+해설)](final_orig/exam13.md) - 13회 문제와 해설 합본 원본
- [Final 모의고사 14회 (문제+해설)](final_orig/exam14.md) - 14회 문제와 해설 합본 원본
- [Final 모의고사 15회 (문제+해설)](final_orig/exam15.md) - 15회 문제와 해설 합본 원본
- [Final 모의고사 16회 (문제+해설)](final_orig/exam16.md) - 16회 문제와 해설 합본 원본

## 기출문제

- [2026년 1회 기출문제 해설](past_exam/2026-1.md) - 2026년 1회 정보처리기사 실기 기출 복원 및 해설

## 개인 학습 기록

- [정보처리기사 실기 개인 학습 기록](my_study_log.md) - 실시간 퀴즈 풀이 및 오답 노트 기록

